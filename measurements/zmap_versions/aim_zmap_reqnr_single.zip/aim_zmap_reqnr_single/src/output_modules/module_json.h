#include "fieldset.h"

int print_json_fieldset(fieldset_t *fs);
