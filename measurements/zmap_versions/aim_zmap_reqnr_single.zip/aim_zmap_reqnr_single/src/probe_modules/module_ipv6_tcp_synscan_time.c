/*
 * ZMapv6 Copyright 2016 Chair of Network Architectures and Services
 * Technical University of Munich
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 */

// probe module for performing TCP SYN scans over IPv6

// Needed for asprintf
#ifndef _GNU_SOURCE
#define _GNU_SOURCE 1
#endif

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <string.h>
#include <assert.h>

#include "../../lib/includes.h"
#include "../fieldset.h"
#include "probe_modules.h"
#include "packet.h"

probe_module_t module_ipv6_tcp_synscan_time;
static uint32_t num_ports;

struct payload_for_rtt {
	uint32_t sent_tv_sec;
	uint32_t sent_tv_usec;	
};
struct tcp_timestamp{
	uint16_t padding;
	uint8_t option;
	uint8_t length;
	struct payload_for_rtt data;	
};
int ipv6_synscan_time_global_initialize(struct state_conf *state)
{
	num_ports = state->source_port_last - state->source_port_first + 1;

	// Only look at received packets destined to the specified scanning address (useful for parallel zmap scans)
	if (asprintf((char ** restrict) &module_ipv6_tcp_synscan_time.pcap_filter, "%s && ip6 dst host %s", module_ipv6_tcp_synscan_time.pcap_filter, state->ipv6_source_ip) == -1) {
		return 1;
	}

	return EXIT_SUCCESS;
}

int ipv6_synscan_time_init_perthread(void* buf, macaddr_t *src,
		macaddr_t *gw, port_h_t dst_port,
		__attribute__((unused)) void **arg_ptr)
{
	memset(buf, 0, MAX_PACKET_SIZE);
	struct ether_header *eth_header = (struct ether_header *) buf;
	make_eth_header_ethertype(eth_header, src, gw, ETHERTYPE_IPV6);
	struct ip6_hdr *ip6_header = (struct ip6_hdr*)(&eth_header[1]);
	uint16_t payload_len = sizeof(struct tcphdr) + 12; //10 Byte Timestamp Option Field + 2 Byte Padding (TCP Header length field = 4 Bits (f.e 1000) => Value represents length (8) * 32 Bit words = 32 Length in total) 
	make_ip6_header(ip6_header, IPPROTO_TCP, payload_len);
	struct tcphdr *tcp_header = (struct tcphdr*)(&ip6_header[1]);
	make_tcp_header(tcp_header, dst_port, TH_SYN);
	return EXIT_SUCCESS;
}

int ipv6_synscan_time_make_packet(void *buf, UNUSED size_t *buf_len, UNUSED ipaddr_n_t src_ip, UNUSED ipaddr_n_t dst_ip,
        uint8_t ttl, uint32_t *validation, int probe_num, void *arg)
{
	struct ether_header *eth_header = (struct ether_header *) buf;
	struct ip6_hdr *ip6_header = (struct ip6_hdr*) (&eth_header[1]);
	struct tcphdr *tcp_header = (struct tcphdr*) (&ip6_header[1]);
	struct tcp_timestamp *timestamp = (struct tcp_timestamp*) (&tcp_header[1]);
	
	struct timeval tv;
	gettimeofday(&tv, NULL);
	struct payload_for_rtt payload = { .sent_tv_sec = tv.tv_sec, .sent_tv_usec = tv.tv_usec };
	timestamp->option = 8;
	timestamp->length = 10;
	timestamp->data=payload;
	timestamp->padding= 0x0101;//Or nops infront: 0x0101;

	uint32_t tcp_seq = validation[0];
	ip6_header->ip6_src = ((struct in6_addr *) arg)[0];
	ip6_header->ip6_dst = ((struct in6_addr *) arg)[1];
	ip6_header->ip6_ctlun.ip6_un1.ip6_un1_hlim = ttl;

	tcp_header->th_sport = htons(get_src_port(num_ports,
				probe_num, validation));
	tcp_header->th_seq = tcp_seq;
	tcp_header->th_sum = 0;
	tcp_header->th_sum = tcp6_checksum(sizeof(struct tcphdr),
			&ip6_header->ip6_src, &ip6_header->ip6_dst, tcp_header);

	return EXIT_SUCCESS;
}

void ipv6_synscan_time_print_packet(FILE *fp, void* packet)
{
	struct ether_header *ethh = (struct ether_header *) packet;
	struct ip6_hdr *iph = (struct ip6_hdr *) &ethh[1];
	struct tcphdr *tcph = (struct tcphdr *) &iph[1];
	fprintf(fp, "tcp { source: %u | dest: %u | seq: %u | checksum: %#04X }\n",
			ntohs(tcph->th_sport),
			ntohs(tcph->th_dport),
			ntohl(tcph->th_seq),
			ntohs(tcph->th_sum));
	fprintf_ipv6_header(fp, iph);
	fprintf_eth_header(fp, ethh);
	fprintf(fp, "------------------------------------------------------\n");
}

int ipv6_synscan_time_validate_packet(const struct ip *ip_hdr, uint32_t len,
		 __attribute__((unused))uint32_t *src_ip,
		uint32_t *validation)
{
	struct ip6_hdr *ipv6_hdr = (struct ip6_hdr *) ip_hdr;

	if (ipv6_hdr->ip6_ctlun.ip6_un1.ip6_un1_nxt == IPPROTO_TCP) {	
		if ((ntohs(ipv6_hdr->ip6_ctlun.ip6_un1.ip6_un1_plen)) > len) {
			// buffer not large enough to contain expected tcp header, i.e. IPv6 payload
			return 0;
		}
		struct tcphdr *tcp_hdr = (struct tcphdr*) (&ipv6_hdr[1]);
		uint16_t sport = tcp_hdr->th_sport;
		uint16_t dport = tcp_hdr->th_dport;
		// validate source port
		if (ntohs(sport) != zconf.target_port) {
			return 0;
		}
		// validate destination port
		if (!check_dst_port(ntohs(dport), num_ports, validation)) {
			return 0;
		}
		// validate tcp acknowledgement number
		if (htonl(tcp_hdr->th_ack) != htonl(validation[0])+1) {
			return 0;
		}

	 } else if (ipv6_hdr->ip6_nxt == IPPROTO_ICMPV6) {
		//log_debug("ICMPv6 VALIDATION", "ICMPV6 CHECK");
		struct icmp6_hdr *icmp6_header = (struct icmp6_hdr*) (&ipv6_hdr[1]);
		uint64_t type = icmp6_header->icmp6_type;
		uint64_t code = icmp6_header->icmp6_code;
		
		
		//Validation is tricky=> look inside the payload to validate icmp dest unreach	and orig tcp packet
		// SHOULD have 8B of ICMP DEST UNREACH + OLD Packet(IP6+TCP)
		uint32_t p_size = 8 + sizeof(struct ip6_hdr) + sizeof(struct tcphdr);
		if (p_size > len) {
			log_debug("VALIDATION","TOO LONG %i - len: %i", p_size, len);
			return 0;	
		}

		struct ip6_hdr *ip_inner = (struct ip6_hdr *)(icmp6_header + 1);
		struct tcphdr *tcp_inner = (struct tcphdr *)((char *) ip_inner + sizeof(struct ip6_hdr));
				
		// Regenerate validation and tcp checksum based off inner payload
		uint16_t sport = tcp_inner->th_sport;
		uint16_t dport = tcp_inner->th_dport;
		uint32_t seqn = tcp_inner->th_seq;		
		
		//generate validation with original dest IP
		//first absende IP then original dest ip
		validate_gen_ipv6(&ip_inner->ip6_src,&ip_inner->ip6_dst, (uint8_t *) validation);

		if (ntohs(dport) != zconf.target_port) {
			log_debug("ICMPv6 Validation failed","Reason: Dest Port: %i , Target Port: %i", dport, zconf.target_port);
			return 0;
		}
		if (!check_dst_port(ntohs(sport), num_ports, validation)) {
			log_debug("ICMPv6 Validation failed","Reason: Source Port %i", sport);
			return 0;
		}
		//validate tcp acknowledgement number
		if (htonl(tcp_inner->th_ack) != htonl(0)) {
			log_debug("ICMPv6 Validation failed","Reason: Ack number %i  ||| %i", tcp_inner->th_ack,0);
			return 0;
		}
	} 
	return 1; 

}
	



//if adding more ipv6 modules -> put this function in packet.c
//static char *get_orig_dest(struct icmp6_hdr *icmp6_header){ //const u_char *packet
	//struct ether_header *ethh = (struct ether_header *) packet;
	//struct ip6_hdr *ip6h = (struct ip6_hdr *) &ethh[1];
	//struct icmp6_hdr *icmp6_header = (struct icmp6_hdr*) (&ip6h[1]);
	//struct ip6_hdr *ip_inner = (struct ip6_hdr *)(icmp6_header + 1);
	//struct in6_addr dst_ip_out=ip_inner->ip6_dst;
	//char *d_ip=make_ipv6_str(&dst_ip_out);
	//return d_ip;
//}


void ipv6_synscan_time_process_packet(const u_char *packet,
		__attribute__((unused)) uint32_t len, fieldset_t *fs,
		__attribute__((unused)) uint32_t *validation)
{
	struct ether_header *eth_hdr = (struct ether_header *) packet;
	struct ip6_hdr *ipv6_hdr = (struct ip6_hdr *) (&eth_hdr[1]);
	
	log_debug("Probe","probe Module");
	if (ipv6_hdr->ip6_nxt == IPPROTO_TCP) {		
			struct tcphdr *tcp_hdr = (struct tcphdr*) (&ipv6_hdr[1]);
			struct tcp_timestamp *timestamp = (struct tcp_timestamp*) (&tcp_hdr[1]);
			fs_add_uint64(fs, "sport", (uint64_t) ntohs(tcp_hdr->th_sport));
			fs_add_uint64(fs, "dport", (uint64_t) ntohs(tcp_hdr->th_dport));
			fs_add_uint64(fs, "seqnum", (uint64_t) ntohl(tcp_hdr->th_seq));
			fs_add_uint64(fs, "acknum", (uint64_t) ntohl(tcp_hdr->th_ack));
			fs_add_uint64(fs, "window", (uint64_t) ntohs(tcp_hdr->th_win));
			fs_add_uint64(fs, "original_ttl", (ipv6_hdr->ip6_ctlun.ip6_un1.ip6_un1_hlim));
			fs_add_uint64(fs, "sent_timestamp_ts", (uint64_t)timestamp->data.sent_tv_sec);
			fs_add_uint64(fs, "sent_timestamp_us", (uint64_t)timestamp->data.sent_tv_usec);

		if (tcp_hdr->th_flags & TH_RST) { // RST packet
			fs_add_string(fs, "classification", (char*) "rst", 0);			
			fs_add_string(fs, "orig-dest-ip", (char*) "#",0);
			fs_add_uint64(fs, "success", 1);
		} else if (tcp_hdr->th_flags & 0x12){ // SYNACK packet) 
			fs_add_string(fs, "classification", (char*) "synack", 0);
			fs_add_string(fs, "orig-dest-ip", (char*) "#",0);
			fs_add_uint64(fs, "success", 1);
		} else {
			fs_add_string(fs, "classification", (char*) "other_tcp_flag", 0);
			fs_add_string(fs, "orig-dest-ip", (char*) "#",0);
			fs_add_uint64(fs, "success", 1);		
		}
		log_debug("Probe","Orig-dest-ip %s", "#");

	} else if (ipv6_hdr->ip6_nxt == IPPROTO_ICMPV6){
		fs_add_uint64(fs, "sport",0);
		fs_add_uint64(fs, "dport", 0);
		fs_add_uint64(fs, "seqnum", 0);
		fs_add_uint64(fs, "acknum", 0);
		fs_add_uint64(fs, "window", 0);
		struct icmp6_hdr *icmp6_header = (struct icmp6_hdr*) (&ipv6_hdr[1]);	
		struct ip6_hdr *ip6_inner = (struct ip6_hdr *)(icmp6_header + 1);
		struct tcphdr *tcp_inner = (struct tcphdr*) (&ip6_inner[1]);
		struct tcp_timestamp *timestamp_inner = (struct tcp_timestamp*) (&tcp_inner[1]);


		struct in6_addr dst_ip_out=ip6_inner->ip6_dst;
		char *orig_dest_ip=make_ipv6_str(&dst_ip_out);

		fs_add_uint64(fs, "original_ttl", (ip6_inner->ip6_ctlun.ip6_un1.ip6_un1_hlim));
		fs_add_uint64(fs, "sent_timestamp_ts", (uint64_t)timestamp_inner->data.sent_tv_sec);
		fs_add_uint64(fs, "sent_timestamp_us", (uint64_t)timestamp_inner->data.sent_tv_usec);

		if(icmp6_header->icmp6_type == ICMP6_DST_UNREACH) {
			switch (icmp6_header ->icmp6_code) {
				case 0:
					fs_add_string(fs, "classification", (char*) "unreach_noroute", 0);					
					break;
				case ICMP6_DST_UNREACH_ADMIN:
					fs_add_string(fs, "classification", (char*) "unreach_admin", 0);					
					break;
	            		case ICMP6_DST_UNREACH_BEYONDSCOPE:
                    			fs_add_string(fs, "classification", (char*) "unreach_beyondscope", 0);     
                    			break;
				case ICMP6_DST_UNREACH_ADDR:
					fs_add_string(fs, "classification", (char*) "unreach_addr", 0);			
					break;
				case ICMP6_DST_UNREACH_NOPORT:
					fs_add_string(fs, "classification", (char*) "unreach_noport", 0);			
					break;
				case 5:
					fs_add_string(fs, "classification", (char*) "unreach_policy", 0);			
					break;
				case 6:
					fs_add_string(fs, "classification", (char*) "unreach_rejectroute", 0);				
					break;
				case 7:
					fs_add_string(fs, "classification", (char*) "unreach_err_src_route", 0);				
					break;
				default:
					fs_add_string(fs, "classification", (char*) "unreach", 0);
					break;

			}

		} else if(icmp6_header->icmp6_type == ICMP6_PACKET_TOO_BIG){
			fs_add_string(fs, "classification", (char*) "toobig", 0);
		} else if(icmp6_header->icmp6_type == ICMP6_PARAM_PROB){
			fs_add_string(fs, "classification", (char*) "paramprob", 0);
		} else if(icmp6_header->icmp6_type == ICMP6_TIME_EXCEEDED) {
			fs_add_string(fs, "classification", (char*) "timxceed", 0);
		} else {
			fs_add_string(fs, "classification", (char*) "other", 0);
		}
		//log_debug("Probe","Orig-dest-ip %s", orig_dest_ip);
		fs_add_string(fs, "orig-dest-ip", orig_dest_ip,1);
		fs_add_uint64(fs, "success",0);		
	}
	else if (ipv6_hdr->ip6_nxt == 44) {
		fs_add_uint64(fs, "sport",0);
		fs_add_uint64(fs, "dport", 0);
		fs_add_uint64(fs, "seqnum", 0);
		fs_add_uint64(fs, "acknum", 0);
		fs_add_uint64(fs, "window", 0);
		fs_add_uint64(fs, "original_ttl", (ipv6_hdr->ip6_ctlun.ip6_un1.ip6_un1_hlim));
		fs_add_uint64(fs, "sent_timestamp_ts", 0);
		fs_add_uint64(fs, "sent_timestamp_us", 0);
		fs_add_string(fs, "classification", (char*) "fragment", 0);
		fs_add_string(fs, "orig-dest-ip", (char*) "#",0);
		fs_add_uint64(fs, "success", 1);		
	}
	else {
		fs_add_uint64(fs, "sport",0);
		fs_add_uint64(fs, "dport", 0);
		fs_add_uint64(fs, "seqnum", 0);
		fs_add_uint64(fs, "acknum", 0);
		fs_add_uint64(fs, "window", 0);
		fs_add_uint64(fs, "original_ttl", (ipv6_hdr->ip6_ctlun.ip6_un1.ip6_un1_hlim));
		fs_add_uint64(fs, "sent_timestamp_ts", 0);
		fs_add_uint64(fs, "sent_timestamp_us", 0);
		fs_add_string(fs, "classification", (char*) "other", 0);
		fs_add_string(fs, "orig-dest-ip", (char*) "#",0);
		fs_add_uint64(fs, "success", 1);	
	}
}

static fielddef_t fields[] = {
	{.name = "sport",  .type = "int", .desc = "TCP source port"},
	{.name = "dport",  .type = "int", .desc = "TCP destination port"},
	{.name = "seqnum", .type = "int", .desc = "TCP sequence number"},
	{.name = "acknum", .type = "int", .desc = "TCP acknowledgement number"},
	{.name = "window", .type = "int", .desc = "TCP window"},
	{.name="original_ttl", .type="int", .desc="original ttl of icmp reply packet"},
	{.name = "sent_timestamp_ts", 
	 .type = "int",
	 .desc = "timestamp of sent probe in seconds since Epoch"},
	{.name = "sent_timestamp_us",
	 .type = "int",
	 .desc = "microsecond part of sent timestamp"},
	{.name = "classification", .type="string", .desc = "packet classification"},	
	{.name="orig-dest-ip", .type="string", .desc="original source ip if icmp err returned"},
	{.name = "success", .type="int", .desc = "is response considered success"}
};

probe_module_t module_ipv6_tcp_synscan_time = {
	.name = "ipv6_tcp_synscan_time",
	.packet_length = 86,  // 74+12 (Timestamp Option + 2 Byte padding)
	.pcap_filter = "icmp6 || (ip6 && tcp)", // old "ip6 proto 6 && (ip6[53] & 4 != 0 || ip6[53] == 18)",
	.pcap_snaplen = 134, // was 96 for IPv4
	.port_args = 1,
	.global_initialize = &ipv6_synscan_time_global_initialize,
	.thread_initialize = &ipv6_synscan_time_init_perthread,
	.make_packet = &ipv6_synscan_time_make_packet,
	.print_packet = &ipv6_synscan_time_print_packet,
	.process_packet = &ipv6_synscan_time_process_packet,
	.validate_packet = &ipv6_synscan_time_validate_packet,
	.close = NULL,
	.helptext = "Probe module that sends an IPv6+TCP SYN packet to a specific "
		"port. Possible classifications are: synack and rst. A "
		"SYN-ACK packet is considered a success and a reset packet "
		"is considered a failed response.",

	.fields = fields,
	.numfields = 11};

