#!/bin/bash

# Permission handling for capturing on enp10s0
ZMAP=src/zmap
setcap cap_net_raw=eip ${ZMAP}

#PYTHON=/usr/bin/python3
#setcap cap_net_raw=eip ${PYTHON}
