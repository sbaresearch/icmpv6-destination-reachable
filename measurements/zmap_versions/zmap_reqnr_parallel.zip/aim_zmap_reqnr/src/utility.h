#ifndef UTILITY_H
#define UTILITY_H

void parse_source_ip_addresses(char given_string[]);

#endif // UTILITY_H
