#ifndef ZMAP_SUMMARY_H
#define ZMAP_SUMMARY_H

#include <stdio.h>

void json_metadata(FILE *);

#endif /* ZMAP_SUMMARY_H */
